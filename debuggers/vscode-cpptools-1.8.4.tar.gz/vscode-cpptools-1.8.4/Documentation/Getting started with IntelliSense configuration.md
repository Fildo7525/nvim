This file is deprecated.

Please find documentation for the C/C++ extension at https://code.visualstudio.com/docs/languages/cpp.