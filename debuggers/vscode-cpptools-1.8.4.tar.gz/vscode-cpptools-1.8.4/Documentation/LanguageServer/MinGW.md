
The documentation for Mingw-w64 has moved to https://code.visualstudio.com/docs/cpp/config-mingw.