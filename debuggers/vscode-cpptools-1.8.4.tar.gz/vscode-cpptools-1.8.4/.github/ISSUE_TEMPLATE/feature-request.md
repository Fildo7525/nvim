---
name: Feature Request
about: Suggest an idea for this extension.
title: ''
labels: ''
assignees: ''

---

Type: Feature Request

<!-- Prior to creating a feature request, please review
existing issues at https://github.com/Microsoft/vscode-cpptools/issues
to avoid creating duplicates.
-->

<!-- Describe the feature you'd like. -->
